package in.visiontech.indiancricketteam;

import java.io.Serializable;

public class Team implements Serializable {
    Integer image;
    String player,role;

    public Team(Integer image) {
        this.image = image;
    }

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public Team() {
    }

    public Team(String player, String role) {
        this.player = player;
        this.role = role;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
