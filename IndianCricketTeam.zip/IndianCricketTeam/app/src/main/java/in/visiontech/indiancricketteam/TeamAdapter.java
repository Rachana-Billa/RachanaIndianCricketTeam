package in.visiontech.indiancricketteam;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TeamAdapter extends RecyclerView.Adapter<TeamAdapter.MyViewholder> {
    Context context;
    ArrayList<Team> arrayList;
    int currentPosition;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    public TeamAdapter(Context context, ArrayList<Team> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public TeamAdapter.MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.card_item,parent,false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeamAdapter.MyViewholder holder, int position) {
        Team team=arrayList.get(position);
        holder.playertxt.setText(team.getPlayer());
        holder.roletxt.setText(team.getRole());

        if(team.getRole().equals("Wicketkeeper")){
            holder.img.setImageResource(R.drawable.wicketkeeping);
        }
        if(team.getRole().equals("Batsman")){
            holder.img.setImageResource(R.drawable.batsman);
        }
        if(team.getRole().equals("All Rounder")){
            holder.img.setImageResource(R.drawable.allrounder);
        }
        if(team.getRole().equals("Bowler")){
            holder.img.setImageResource(R.drawable.bowlerr);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PopupMenu popupMenu = new PopupMenu(context, v);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                currentPosition = holder.getAdapterPosition();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getItemId() == R.id.edit) {
                            editTeam();

                        }
                        if (item.getItemId() == R.id.delete) {
                            deleteTeam();

                        }
                        return true;
                    }
                });
                popupMenu.show();

                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(context,Details.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                in.putExtra("positionKey",team);
                v.getContext().startActivity(in);
            }
        });
    }

    private void deleteTeam() {
        Team team2=arrayList.get(currentPosition);
        databaseReference=FirebaseDatabase.getInstance().getReference("IndianTeam");
        Query query=databaseReference.orderByChild("player").equalTo(team2.getPlayer());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    dataSnapshot.getRef().removeValue();
                    notifyDataSetChanged();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void editTeam() {
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewholder extends RecyclerView.ViewHolder {
        TextView playertxt,roletxt;
        ImageView img;
        public MyViewholder(@NonNull View itemView) {
            super(itemView);
            playertxt=itemView.findViewById(R.id.card_player);
            roletxt=itemView.findViewById(R.id.card_role);
            img=itemView.findViewById(R.id.img);


        }
    }
}
