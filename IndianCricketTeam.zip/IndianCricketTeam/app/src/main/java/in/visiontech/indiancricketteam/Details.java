package in.visiontech.indiancricketteam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Details extends AppCompatActivity {
    TextView player,role;
    ImageView img1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        player=findViewById(R.id.player_details);
        role=findViewById(R.id.role_details);
        img1=findViewById(R.id.img_detalis);

        Intent in=getIntent();
        Team team3= (Team) in.getSerializableExtra("positionKey");
        player.setText(team3.getPlayer());
        role.setText(team3.getRole());

        if(team3.getRole().equals("Wicketkeeper")){
            img1.setImageResource(R.drawable.wicketkeeping);
        }
        if(team3.getRole().equals("Batsman")){
            img1.setImageResource(R.drawable.batsman);
        }
        if(team3.getRole().equals("All Rounder")){
            img1.setImageResource(R.drawable.allrounder);
        }
        if(team3.getRole().equals("Bowler")){
            img1.setImageResource(R.drawable.bowlerr);
        }


    }
}