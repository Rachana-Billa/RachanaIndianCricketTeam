package in.visiontech.indiancricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<Team> arrayList;
    FirebaseDatabase firebaseDatabase;
    TeamAdapter teamAdapter;
    DatabaseReference databaseReference;
    String playerS,roleS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("IndianTeam");


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayList=new ArrayList<>();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Team team1=dataSnapshot.getValue(Team.class);
                    arrayList.add(team1);

                }
                teamAdapter=new TeamAdapter(getApplicationContext(),arrayList);
                recyclerView.setAdapter(teamAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        TextView title;
        Spinner cricketer,role;
        Button add;
        switch (item.getItemId()){
            case R.id.plus:
                Dialog dialog=new Dialog(this);
                dialog.setContentView(R.layout.alert_layout);
                dialog.show();

                title=dialog.findViewById(R.id.title);
                cricketer=dialog.findViewById(R.id.player);
                role=dialog.findViewById(R.id.role);
                ArrayAdapter<CharSequence> arr1=ArrayAdapter.createFromResource(getApplicationContext(),R.array.Player, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                cricketer.setAdapter(arr1);

                cricketer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        playerS=cricketer.getItemAtPosition(position).toString();

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                ArrayAdapter<CharSequence> arr2=ArrayAdapter.createFromResource(getApplicationContext(),R.array.role, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                role.setAdapter(arr2);
                role.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        roleS=role.getItemAtPosition(position).toString();


                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                add=dialog.findViewById(R.id.add);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        addDatatoFirebase(playerS,roleS);
                        dialog.dismiss();



                    }
                });



                break;
        }



        return super.onOptionsItemSelected(item);

    }

    private void addDatatoFirebase(String playerS, String roleS) {
        Team team=new Team(playerS,roleS);
        databaseReference.push().setValue(team);
    }

}
